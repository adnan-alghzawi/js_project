# finalVersion

https://trello.com/invite/b/677fd2abad43100b3fa6d21d/ATTI12439c36bce2c4e9aac028394ddeeb4b7FE7B769/js-project



https://www.figma.com/design/QcvNFKiCOv80tsbzVXbDhg/Untitled?node-id=0-1&t=zGLSUziBkNBw86pP-1